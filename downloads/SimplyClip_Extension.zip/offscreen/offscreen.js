// offscreen.js — ffmpeg.wasm clip trimming

let ffmpegInstance = null;
let ffmpegLoadPromise = null;

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    document.head.appendChild(script);
  });
}

async function getFFmpeg() {
  if (ffmpegInstance) return ffmpegInstance;
  if (ffmpegLoadPromise) return ffmpegLoadPromise;

  ffmpegLoadPromise = (async () => {
    await loadScript('https://unpkg.com/@ffmpeg/ffmpeg@0.12.6/dist/umd/ffmpeg.js');

    const FFmpegClass = globalThis.FFmpegWASM?.FFmpeg || globalThis.FFmpeg;
    if (!FFmpegClass) {
      throw new Error('FFmpeg UMD bundle did not load');
    }

    const ffmpeg = new FFmpegClass();
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
    await ffmpeg.load({
      coreURL: `${baseURL}/ffmpeg-core.js`,
      wasmURL: `${baseURL}/ffmpeg-core.wasm`,
    });

    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  return ffmpegLoadPromise;
}

async function trimVideo({ streamUrl, startSec, endSec }) {
  const response = await fetch(streamUrl);
  if (!response.ok) {
    throw new Error(`Failed to fetch stream (${response.status})`);
  }

  const buffer = await response.arrayBuffer();
  const ffmpeg = await getFFmpeg();

  await ffmpeg.writeFile('input.mp4', new Uint8Array(buffer));
  await ffmpeg.exec([
    '-ss', String(startSec),
    '-to', String(endSec),
    '-i', 'input.mp4',
    '-c', 'copy',
    'output.mp4',
  ]);

  const output = await ffmpeg.readFile('output.mp4');
  const blob = new Blob([output], { type: 'video/mp4' });
  return URL.createObjectURL(blob);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== 'TRIM_VIDEO') return;

  (async () => {
    try {
      const { streamUrl, startSec, endSec, filename } = msg;
      const blobUrl = await trimVideo({ streamUrl, startSec, endSec });
      sendResponse({ blobUrl, filename });
    } catch (err) {
      sendResponse({ error: err.message || 'Trim failed' });
    }
  })();

  return true;
});
