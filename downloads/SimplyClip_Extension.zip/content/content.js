// content.js — injected into youtube.com/watch pages
// Handles: video info extraction, bracket markers on timeline, download via yt-dlp API

(function() {
  'use strict';

  // ── Message handler ────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.action) {

      case 'GET_VIDEO_INFO':
        sendResponse(getVideoInfo());
        break;

      case 'GET_CURRENT_TIME':
        sendResponse({ currentTime: getCurrentTime() });
        break;

      case 'DOWNLOAD_CLIP':
        handleDownload(msg).then(result => sendResponse(result));
        return true; // async

      case 'SET_BRACKET':
        setBracket(msg.type, msg.time);
        sendResponse({ ok: true });
        break;
    }
    return true;
  });

  // ── Get video info ─────────────────────────────────────
  function getVideoInfo() {
    const video = document.querySelector('video');
    const duration = video ? video.duration : 0;
    const currentTime = video ? video.currentTime : 0;

    // Try to get title
    const titleEl = document.querySelector('h1.ytd-video-primary-info-renderer yt-formatted-string') ||
                    document.querySelector('#title h1') ||
                    document.querySelector('h1.title');
    const title = titleEl ? titleEl.textContent.trim() : document.title.replace(' - YouTube', '');

    const formats = extractFormats();
    const bestStreamUrl = getBestStreamUrl();

    return { duration, currentTime, title, formats, bestStreamUrl };
  }

  function getBestStreamUrl() {
    try {
      const scripts = document.querySelectorAll('script');
      for (const script of scripts) {
        const text = script.textContent;
        if (!text.includes('ytInitialPlayerResponse')) continue;
        const match = text.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\});/s);
        if (!match) continue;
        const data = JSON.parse(match[1]);
        const allFormats = [
          ...(data?.streamingData?.formats || []),
          ...(data?.streamingData?.adaptiveFormats || []),
        ];
        const withUrl = allFormats.filter(f => f.url && f.mimeType?.includes('video'));
        if (withUrl.length === 0) return null;
        withUrl.sort((a, b) => (b.width || 0) - (a.width || 0));
        return withUrl[0].url;
      }
    } catch (e) {}
    return null;
  }

  function getCurrentTime() {
    const video = document.querySelector('video');
    return video ? video.currentTime : 0;
  }

  // ── Extract formats from page ──────────────────────────
  function extractFormats() {
    try {
      const scripts = document.querySelectorAll('script');
      for (const script of scripts) {
        const text = script.textContent;
        if (!text.includes('ytInitialPlayerResponse')) continue;

          const match = text.match(/ytInitialPlayerResponse\s*=\s*(\{.+?\});/s);
        if (!match) continue;

            const data = JSON.parse(match[1]);
            const streamingData = data?.streamingData;
            if (!streamingData) continue;

        const rawFormats = [
              ...(streamingData.formats || []),
          ...(streamingData.adaptiveFormats || []),
            ];

            const seen = new Set();
            const result = [];

        for (const f of rawFormats) {
          const q = f.qualityLabel
            ? f.qualityLabel.replace('p', '').replace(/[^0-9]/g, '')
            : '';

          const key = q || String(f.itag || '');
          if (key && seen.has(key)) continue;
          if (key) seen.add(key);

              result.push({
                quality: q,
                itag: f.itag,
                mimeType: f.mimeType || '',
            url: f.url || null,
              });
        }

        result.sort((a, b) => parseInt(b.quality || 0, 10) - parseInt(a.quality || 0, 10));
        return result;
      }
    } catch (e) {}
    return [];
  }

  // ── Bracket markers on YouTube timeline ───────────────
  let bracketStart = null;
  let bracketEnd = null;
  let bracketStartEl = null;
  let bracketEndEl = null;

  function setBracket(type, time) {
    const progressBar = document.querySelector('.ytp-progress-bar-container') ||
                        document.querySelector('.ytp-chrome-bottom');
    if (!progressBar) return;

    if (type === 'start') {
      bracketStart = time;
      if (!bracketStartEl) {
        bracketStartEl = createBracketEl('start');
        progressBar.appendChild(bracketStartEl);
      }
      positionBracket(bracketStartEl, time);
    } else {
      bracketEnd = time;
      if (!bracketEndEl) {
        bracketEndEl = createBracketEl('end');
        progressBar.appendChild(bracketEndEl);
      }
      positionBracket(bracketEndEl, time);
    }
  }

  function createBracketEl(type) {
    const el = document.createElement('div');
    el.className = `ytc-bracket ytc-bracket-${type}`;
    el.textContent = type === 'start' ? '[' : ']';
    el.style.cssText = `
      position: absolute;
      bottom: 100%;
      color: #FF0000;
      font-size: 16px;
      font-weight: 900;
      pointer-events: none;
      z-index: 9999;
      text-shadow: 0 1px 3px rgba(0,0,0,0.8);
      transform: translateX(-50%);
      transition: left 0.1s;
    `;
    return el;
  }

  function positionBracket(el, time) {
    const video = document.querySelector('video');
    if (!video || !video.duration) return;
    const pct = (time / video.duration) * 100;
    el.style.left = `${pct}%`;
  }

  // ── Keyboard shortcuts: [ and ] ────────────────────────
  // These let users mark clip points while watching
  document.addEventListener('keydown', e => {
    // Don't fire if typing in an input
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

    const video = document.querySelector('video');
    if (!video) return;

    if (e.key === '[') {
      const time = video.currentTime;
      setBracket('start', time);
      chrome.storage.local.set({ bracketStart: time }, () => {
        const panel = document.getElementById('ytc-dropdown-panel');
        if (panel && panel.style.display !== 'none') {
          const iframe = panel.querySelector('iframe');
          if (iframe && iframe.contentWindow) {
            iframe.contentWindow.postMessage({
              type: 'YTC_BRACKET_UPDATE',
              bracketStart: time
            }, '*');
          }
        }
      });
      showBracketToast(`[ Start set — ${formatTime(time)}`);
    }

    if (e.key === ']') {
      const time = video.currentTime;
      setBracket('end', time);
      chrome.storage.local.set({ bracketEnd: time }, () => {
        const panel = document.getElementById('ytc-dropdown-panel');
        if (panel && panel.style.display !== 'none') {
          const iframe = panel.querySelector('iframe');
          if (iframe && iframe.contentWindow) {
            iframe.contentWindow.postMessage({
              type: 'YTC_BRACKET_UPDATE',
              bracketEnd: time
            }, '*');
          }
        }
      });
      showBracketToast(`] End set — ${formatTime(time)}`);
    }
  });

  function formatTime(secs) {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = Math.floor(secs % 60);
    const parts = [];
    if (h) parts.push(String(h).padStart(2, '0'));
    parts.push(String(m).padStart(2, '0'));
    parts.push(String(s).padStart(2, '0'));
    return parts.join(':');
  }

  function showBracketToast(msg) {
    let toast = document.getElementById('ytc-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ytc-toast';
      toast.style.cssText = `
        position: fixed;
        bottom: 80px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0,0,0,0.85);
        color: #fff;
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 13px;
        font-family: -apple-system, sans-serif;
        font-weight: 500;
        z-index: 99999;
        pointer-events: none;
        border-left: 3px solid #FF0000;
        backdrop-filter: blur(4px);
        transition: opacity 0.3s;
      `;
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
  }

  function forceHighestQuality() {
    return new Promise((resolve) => {
      try {
        const player = document.querySelector('#movie_player') ||
                       document.querySelector('.html5-video-player');
        if (player && typeof player.setPlaybackQuality === 'function') {
          player.setPlaybackQuality('hd1080');
          if (typeof player.setPlaybackQualityRange === 'function') {
            player.setPlaybackQualityRange('hd1080', 'hd1080');
          }
        }
        setTimeout(resolve, 1500);
      } catch (e) {
        resolve();
      }
    });
  }

  // ── Download handler ───────────────────────────────────
  async function handleDownload(msg) {
    const { startSec, endSec, videoTitle, fullVideo } = msg;
    const video = document.querySelector('video');
    if (!video) return { error: 'No video found on page' };

    chrome.storage.local.set({
      downloadStatus: {
        status: 'progress', progress: 1,
        label: 'Setting quality to highest...'
      }
    });
    await forceHighestQuality();

    const clipStart = fullVideo ? 0 : startSec;
    const clipEnd = fullVideo ? video.duration : endSec;
    const duration = clipEnd - clipStart;

    return new Promise((resolve) => {

      function isRangeBuffered(start, end) {
        for (let i = 0; i < video.buffered.length; i++) {
          if (video.buffered.start(i) <= start + 0.5 &&
              video.buffered.end(i) >= end - 0.5) {
            return true;
          }
        }
        return false;
      }

      function doRecord() {
        let stopped = false;
        let recorder;
        let stream;
        let stopCheck;
        let progressInterval;

        function stopRecording() {
          if (stopped) return;
          stopped = true;
          clearInterval(stopCheck);
          clearInterval(progressInterval);
          try { recorder.stop(); } catch(e) {}
          video.pause();
          try { stream.getTracks().forEach(t => t.stop()); } catch(e) {}
        }

        video.pause();
        video.currentTime = clipStart;

        video.addEventListener('seeked', function onSeeked() {
          video.removeEventListener('seeked', onSeeked);

          stream = video.captureStream();
          const chunks = [];

          let mimeType = 'video/webm;codecs=vp8,opus';
          if (!MediaRecorder.isTypeSupported(mimeType)) {
            mimeType = 'video/webm';
          }

          recorder = new MediaRecorder(stream, {
            mimeType,
            videoBitsPerSecond: 8000000
          });

          recorder.ondataavailable = e => {
            if (e.data && e.data.size > 0) chunks.push(e.data);
          };

          recorder.onstop = () => {
            const webmBlob = new Blob(chunks, { type: 'video/webm' });
            const safe = (videoTitle || 'clip')
              .replace(/[<>:"/\\|?*]/g, '').trim().slice(0, 80);

            chrome.storage.local.set({
              downloadStatus: { status: 'progress', progress: 97,
                label: 'Saving file...' }
            });

            const url = URL.createObjectURL(webmBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = safe + '.mp4';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(() => URL.revokeObjectURL(url), 5000);

            chrome.storage.local.set({
              downloadStatus: { status: 'done' }
            });
            resolve({ ok: true });
          };

          recorder.onerror = e => {
            resolve({ error: 'Recorder error: ' + e.message });
          };

          recorder.start(100);
          video.play();

          const startTs = Date.now();
          const totalMs = duration * 1000;

          progressInterval = setInterval(() => {
            const elapsed = Date.now() - startTs;
            const pct = Math.min(
              Math.round((elapsed / totalMs) * 95), 95
            );
            chrome.storage.local.set({
              downloadStatus: {
                status: 'progress', progress: pct,
                label: `Recording ${Math.round(elapsed/1000)}s of ${Math.round(duration)}s`
              }
            });
          }, 500);

          stopCheck = setInterval(() => {
            if (video.currentTime >= clipEnd - 0.1) {
              stopRecording();
            }
          }, 100);

          setTimeout(() => stopRecording(), (duration + 2) * 1000);
        });
      }

      function bufferClip() {
        chrome.storage.local.set({
          downloadStatus: {
            status: 'progress', progress: 2,
            label: 'Buffering clip...'
          }
        });

        video.pause();
        video.muted = true;
        video.playbackRate = 4;
        video.currentTime = clipStart;

        const checkBuffer = setInterval(() => {
          if (isRangeBuffered(clipStart, clipEnd)) {
            clearInterval(checkBuffer);
            clearTimeout(bufferTimeout);
            video.pause();
            video.playbackRate = 1;
            video.muted = false;
            chrome.storage.local.set({
              downloadStatus: {
                status: 'progress', progress: 10,
                label: 'Buffered. Starting recording...'
              }
            });
            setTimeout(doRecord, 300);
            return;
          }

          if (video.currentTime >= clipEnd) {
            clearInterval(checkBuffer);
            clearTimeout(bufferTimeout);
            video.pause();
            video.playbackRate = 1;
            video.muted = false;
            setTimeout(doRecord, 300);
          }
        }, 200);

        video.play().catch(() => {});

        const bufferTimeout = setTimeout(() => {
          clearInterval(checkBuffer);
          video.pause();
          video.playbackRate = 1;
          video.muted = false;
          doRecord();
        }, 15000);
      }

      if (isRangeBuffered(clipStart, clipEnd)) {
        chrome.storage.local.set({
          downloadStatus: {
            status: 'progress', progress: 10,
            label: 'Already buffered. Starting recording...'
          }
        });
        doRecord();
      } else {
        bufferClip();
      }

    });
  }

  // ── "Clip" button + inline dropdown panel ───────────────
  const CLIP_BTN_ID = 'ytc-clip-btn';
  const DROPDOWN_PANEL_ID = 'ytc-dropdown-panel';
  const PANEL_WIDTH = 320;
  function findSubscribeAnchor() {
    // Target the top-level owner row which is a flex container
    const ownerRow =
      document.querySelector('ytd-video-owner-renderer') ||
      document.querySelector('#owner');
    if (!ownerRow) return null;

    // Find the subscribe button within that row
    const subscribeBtn =
      ownerRow.querySelector('#subscribe-button') ||
      ownerRow.querySelector('ytd-subscribe-button-renderer');

    return subscribeBtn || null;
  }

  function injectClipButton() {
    if (document.getElementById(CLIP_BTN_ID)) return;

    // Log everything we can find
    console.log('[YTC] Attempting inject...');
    console.log('[YTC] #subscribe-button:', document.querySelector('#subscribe-button'));
    console.log('[YTC] ytd-subscribe-button-renderer:', document.querySelector('ytd-subscribe-button-renderer'));
    console.log('[YTC] #owner:', document.querySelector('#owner'));
    console.log('[YTC] ytd-video-owner-renderer:', document.querySelector('ytd-video-owner-renderer'));
    console.log('[YTC] #above-the-fold:', document.querySelector('#above-the-fold'));

    const anchor = document.querySelector('#subscribe-button') ||
                   document.querySelector('ytd-subscribe-button-renderer');

    if (!anchor) {
      console.log('[YTC] No anchor found, aborting');
      return;
    }

    console.log('[YTC] Anchor found:', anchor);
    console.log('[YTC] Anchor parent:', anchor.parentNode);
    console.log('[YTC] Anchor parent tag:', anchor.parentNode?.tagName);
    console.log('[YTC] Anchor parent id:', anchor.parentNode?.id);
    console.log('[YTC] Anchor parent children:', anchor.parentNode?.children);

    const parent = anchor.parentNode;
    if (!parent) return;

    const btn = document.createElement('button');
    btn.id = CLIP_BTN_ID;
    btn.textContent = '✂ Clip';
    btn.style.cssText = 'background:#272727;color:#fff;border:none;border-radius:20px;padding:0 16px;height:36px;font-size:14px;font-weight:500;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;flex-shrink:0;';
    btn.style.marginLeft = '8px';
    btn.style.marginRight = '8px';
    btn.addEventListener('mouseenter', () => btn.style.background = '#3f3f3f');
    btn.addEventListener('mouseleave', () => btn.style.background = '#272727');
    btn.addEventListener('click', e => { e.stopPropagation(); toggleDropdown(btn); });
    anchor.insertAdjacentElement('afterend', btn);
    console.log('[YTC] Button injected successfully');
  }

  function removeClipButton() {
    document.getElementById(CLIP_BTN_ID)?.remove();
  }

  function getDropdownPanel() {
    let panel = document.getElementById(DROPDOWN_PANEL_ID);
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = DROPDOWN_PANEL_ID;
    panel.style.cssText = 'position:fixed;z-index:2147483647;width:320px;background:#1e1e1e;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.6);border:1px solid #333;overflow:hidden;display:none;';

    const lockBtn = document.createElement('button');
    lockBtn.id = 'ytc-lock-btn';
    lockBtn.title = 'Lock panel open';
    lockBtn.style.cssText = [
      'position:absolute',
      'top:10px',
      'right:10px',
      'z-index:99',
      'background:#2a2a2a',
      'border:none',
      'border-radius:50%',
      'width:22px',
      'height:22px',
      'cursor:pointer',
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'padding:0',
    ].join(';');

    const LOCK_ICON = `<svg width="12" height="12" viewBox="0 0 24 24" 
    fill="none" stroke="#999" stroke-width="2.5" 
    stroke-linecap="round" stroke-linejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2"/>
    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
  </svg>`;

    const UNLOCK_ICON = `<svg width="12" height="12" viewBox="0 0 24 24" 
    fill="none" stroke="#fff" stroke-width="2.5" 
    stroke-linecap="round" stroke-linejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2"/>
    <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
  </svg>`;

    lockBtn.innerHTML = LOCK_ICON;
    let isLocked = false;

    lockBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      isLocked = !isLocked;
      lockBtn.style.background = isLocked ? '#7d1c2e' : '#2a2a2a';
      lockBtn.innerHTML = isLocked ? UNLOCK_ICON : LOCK_ICON;
      lockBtn.title = isLocked ? 'Unlock panel' : 'Lock panel open';
    });

    panel._isLocked = () => isLocked;

    panel.appendChild(lockBtn);

    const iframe = document.createElement('iframe');
    iframe.src = chrome.runtime.getURL('popup/popup.html');
    iframe.style.cssText = 'width:320px;height:520px;border:none;display:block;';
    panel.appendChild(iframe);
    panel.addEventListener('click', e => e.stopPropagation());
    document.body.appendChild(panel);
    return panel;
  }

  function positionDropdown(btn) {
    const panel = getDropdownPanel();
    const rect = btn.getBoundingClientRect();
    let left = rect.left;
    if (left + PANEL_WIDTH > window.innerWidth - 8) left = window.innerWidth - PANEL_WIDTH - 8;
    if (left < 8) left = 8;
    const panelHeight = 520;
    const top = rect.bottom + 8 + panelHeight > window.innerHeight
      ? rect.top - panelHeight - 8
      : rect.bottom + 8;
    panel.style.top = top + 'px';
    panel.style.left = left + 'px';
  }

  function isDropdownOpen() {
    const p = document.getElementById(DROPDOWN_PANEL_ID);
    return p && p.style.display !== 'none';
  }

  function openDropdown(btn) {
    const panel = getDropdownPanel();
    positionDropdown(btn);
    panel.style.display = 'block';
  }

  function closeDropdown() {
    const p = document.getElementById(DROPDOWN_PANEL_ID);
    if (!p) return;
    if (p._isLocked && p._isLocked()) return;
    p.style.display = 'none';
  }

  function forceCloseDropdown() {
    const p = document.getElementById(DROPDOWN_PANEL_ID);
    if (p) p.style.display = 'none';
  }

  function toggleDropdown(btn) {
    isDropdownOpen() ? closeDropdown() : openDropdown(btn);
  }

  function trackDropdownPosition() {
    if (!isDropdownOpen()) {
      requestAnimationFrame(trackDropdownPosition);
      return;
    }
    const btn = document.getElementById(CLIP_BTN_ID);
    if (btn) {
      const rect = btn.getBoundingClientRect();
      const panel = document.getElementById(DROPDOWN_PANEL_ID);
      if (panel) {
        let left = rect.left;
        if (left + PANEL_WIDTH > window.innerWidth - 8) {
          left = window.innerWidth - PANEL_WIDTH - 8;
        }
        if (left < 8) left = 8;
        panel.style.top = (rect.bottom + 8) + 'px';
        panel.style.left = left + 'px';
      }
    }
    requestAnimationFrame(trackDropdownPosition);
  }

  trackDropdownPosition();

  document.addEventListener('click', e => {
    if (!isDropdownOpen()) return;
    const panel = document.getElementById(DROPDOWN_PANEL_ID);
    const btn = document.getElementById(CLIP_BTN_ID);
    if (panel?.contains(e.target) || btn?.contains(e.target)) return;
    closeDropdown();
  });

  function onYouTubeNavigation() {
    chrome.storage.local.remove(['bracketStart', 'bracketEnd']);
    forceCloseDropdown();
    document.getElementById(DROPDOWN_PANEL_ID)?.remove();
    removeClipButton();
    setTimeout(injectClipButton, 1500);
  }

  document.addEventListener('yt-navigate-finish', onYouTubeNavigation);

  // Retry loop — keeps trying every 800ms until button appears
  let injectAttempts = 0;
  const injectInterval = setInterval(() => {
    injectClipButton();
    injectAttempts++;
    if (document.getElementById(CLIP_BTN_ID) || injectAttempts > 20) {
      clearInterval(injectInterval);
    }
  }, 800);

  async function remuxToMp4(webmBlob) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/@ffmpeg/ffmpeg@0.12.6/dist/umd/ffmpeg.js';
      script.onload = async () => {
        try {
          const { FFmpeg } = window.FFmpeg;
          const ffmpeg = new FFmpeg();

          await ffmpeg.load({
            coreURL: 'https://unpkg.com/@ffmpeg/core@0.12.4/dist/umd/ffmpeg-core.js'
          });

          const inputData = new Uint8Array(await webmBlob.arrayBuffer());
          await ffmpeg.writeFile('input.webm', inputData);

          await ffmpeg.exec([
            '-i', 'input.webm',
            '-c', 'copy',
            'output.mp4'
          ]);

          const outputData = await ffmpeg.readFile('output.mp4');
          const mp4Blob = new Blob([outputData.buffer], { type: 'video/mp4' });
          resolve(mp4Blob);
        } catch (e) {
          reject(e);
        }
      };
      script.onerror = () => reject(new Error('Failed to load ffmpeg'));
      document.head.appendChild(script);
    });
  }

})();
