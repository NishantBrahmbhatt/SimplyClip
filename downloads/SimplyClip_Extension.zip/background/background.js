const HELPER_URL = 'http://localhost:9999';
const RELAY_ACTIONS = ['GET_VIDEO_INFO', 'GET_CURRENT_TIME', 
                       'DOWNLOAD_CLIP', 'GET_QUALITIES'];

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // Relay popup messages to active tab content script
  if (RELAY_ACTIONS.includes(msg.action)) {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs[0]) {
        sendResponse({ error: 'No active tab' });
        return;
      }
      chrome.tabs.sendMessage(tabs[0].id, msg, response => {
        if (chrome.runtime.lastError) {
          sendResponse({ error: chrome.runtime.lastError.message });
          return;
        }
        sendResponse(response);
      });
    });
    return true;
  }

  // Check if helper is running
  if (msg.action === 'CHECK_HELPER') {
    fetch(`${HELPER_URL}/ping`)
      .then(r => r.json())
      .then(data => sendResponse({ ok: true, data }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  // Start a clip download job
  if (msg.action === 'START_CLIP') {
    fetch(`${HELPER_URL}/clip`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg.payload)
    })
      .then(r => r.json())
      .then(data => sendResponse(data))
      .catch(e => sendResponse({ 
        status: 'error', 
        message: 'Helper not running. Please start the helper first.' 
      }));
    return true;
  }

  // Poll progress
  if (msg.action === 'GET_PROGRESS') {
    fetch(`${HELPER_URL}/progress`)
      .then(r => r.json())
      .then(data => sendResponse(data))
      .catch(() => sendResponse({ 
        status: 'error', 
        message: 'Lost connection to helper.' 
      }));
    return true;
  }

  // Get available qualities for a video
  if (msg.action === 'GET_QUALITIES') {
    fetch(`${HELPER_URL}/qualities?videoId=${msg.videoId}`)
      .then(r => r.json())
      .then(data => sendResponse(data))
      .catch(() => sendResponse({ qualities: ['1080','720','480','360'] }));
    return true;
  }

});
