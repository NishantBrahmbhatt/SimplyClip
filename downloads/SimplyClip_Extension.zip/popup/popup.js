// ── Helpers ─────────────────────────────────────────────
function pad(n) { return String(Math.floor(n)).padStart(2, '0'); }

function secondsToHMS(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return { h, m, s: sec };
}

function hmsToSeconds(h, m, s) {
  return (parseInt(h) || 0) * 3600 + (parseInt(m) || 0) * 60 + (parseInt(s) || 0);
}

function formatDuration(secs) {
  const s = Math.round(secs);
  if (s < 60) return s + 's';
  const m = Math.floor(s / 60);
  const rem = s % 60;
  if (s < 3600) return rem > 0 ? m + 'm ' + rem + 's' : m + 'm';
  const h = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  return mins > 0 ? h + 'h ' + mins + 'm' : h + 'h';
}

function formatHMS(secs) {
  const { h, m, s } = secondsToHMS(secs);
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

// ── State ────────────────────────────────────────────────
let state = {
  videoDuration: 0,
  startSec: 0,
  endSec: 0,
  videoId: null,
  videoTitle: '',
  dragging: null,
  selectedQuality: '1080',
};

// ── DOM refs ─────────────────────────────────────────────
const $ = id => document.getElementById(id);
const notYouTube   = $('notYouTube');
const mainContent  = $('mainContent');
const videoThumb   = $('videoThumb');
const videoTitle   = $('videoTitle');
const videoDuration = $('videoDuration');
const startH = $('startH'), startM = $('startM'), startS = $('startS');
const endH   = $('endH'),   endM   = $('endM'),   endS   = $('endS');
const clipDuration = $('clipDuration');
const downloadBtn  = $('downloadBtn');
const progressWrap = $('progressWrap');
const progressFill = $('progressFill');
const progressLabel = $('progressLabel');
const timelineTrack = $('timelineTrack');
const timelineFill  = $('timelineFill');
const handleStart   = $('handleStart');
const handleEnd     = $('handleEnd');
const labelStart    = $('labelStart');
const labelEnd      = $('labelEnd');
const timelineTicks = $('timelineTicks');
const syncBtn       = $('syncBtn');

// ── Timeline ─────────────────────────────────────────────
function updateTimeline() {
  if (state.videoDuration === 0) return;
  const startPct = (state.startSec / state.videoDuration) * 100;
  const endPct   = (state.endSec   / state.videoDuration) * 100;
  handleStart.style.left = `${startPct}%`;
  handleEnd.style.left   = `${endPct}%`;
  timelineFill.style.left  = `${startPct}%`;
  timelineFill.style.width = `${endPct - startPct}%`;
  labelStart.textContent = formatHMS(state.startSec);
  labelEnd.textContent   = formatHMS(state.endSec);
  const dur = state.endSec - state.startSec;
  clipDuration.textContent = dur > 0 ? formatDuration(dur) : '0s';
}

function buildTicks() {
  timelineTicks.innerHTML = '';
  const totalSec = state.videoDuration;
  const ticks = [0, 0.25, 0.5, 0.75, 1];
  ticks.forEach(pct => {
    const span = document.createElement('span');
    span.className = 'timeline-tick';
    span.textContent = formatHMS(Math.round(pct * totalSec));
    timelineTicks.appendChild(span);
  });
}

function pctFromEvent(e) {
  const rect = timelineTrack.getBoundingClientRect();
  let pct = (e.clientX - rect.left) / rect.width;
  return Math.max(0, Math.min(1, pct));
}

handleStart.addEventListener('mousedown', e => {
  e.preventDefault();
  state.dragging = 'start';
});
handleEnd.addEventListener('mousedown', e => {
  e.preventDefault();
  state.dragging = 'end';
});

document.addEventListener('mousemove', e => {
  if (!state.dragging) return;
  const pct = pctFromEvent(e);
  const sec = Math.round(pct * state.videoDuration);
  if (state.dragging === 'start') {
    state.startSec = Math.min(sec, state.endSec - 1);
    syncInputsFromState();
  } else {
    state.endSec = Math.max(sec, state.startSec + 1);
    syncInputsFromState();
  }
  updateTimeline();
});

document.addEventListener('mouseup', () => { state.dragging = null; });

timelineTrack.addEventListener('click', e => {
  if (e.target === handleStart || e.target === handleEnd) return;
  const pct = pctFromEvent(e);
  const sec = Math.round(pct * state.videoDuration);
  const distStart = Math.abs(sec - state.startSec);
  const distEnd   = Math.abs(sec - state.endSec);
  if (distStart <= distEnd) {
    state.startSec = Math.min(sec, state.endSec - 1);
  } else {
    state.endSec = Math.max(sec, state.startSec + 1);
  }
  syncInputsFromState();
  updateTimeline();
});

// ── Time inputs ──────────────────────────────────────────
function syncInputsFromState() {
  const { h: sh, m: sm, s: ss } = secondsToHMS(state.startSec);
  const { h: eh, m: em, s: es } = secondsToHMS(state.endSec);
  startH.value = sh; startM.value = sm; startS.value = ss;
  endH.value   = eh; endM.value   = em; endS.value   = es;
}

function syncStateFromInputs() {
  state.startSec = Math.round(Math.min(
    hmsToSeconds(startH.value, startM.value, startS.value),
    state.videoDuration
  ));
  state.endSec = Math.round(Math.min(
    hmsToSeconds(endH.value, endM.value, endS.value),
    state.videoDuration
  ));
  if (state.startSec >= state.endSec) {
    state.endSec = Math.round(Math.min(state.startSec + 1, state.videoDuration));
  }
  updateTimeline();
}

[startH, startM, startS, endH, endM, endS].forEach(inp => {
  inp.addEventListener('input', syncStateFromInputs);
  inp.addEventListener('change', syncStateFromInputs);
});

// ── Sync player button ────────────────────────────────────
syncBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'GET_CURRENT_TIME' },
  response => {
    if (response && response.currentTime !== undefined) {
      state.startSec = Math.round(response.currentTime);
      state.endSec = Math.round(state.videoDuration);
      syncInputsFromState();
      updateTimeline();
    }
  });
});

// ── Quality selector ─────────────────────────────────────
document.querySelectorAll('.quality-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.quality-item')
      .forEach(i => i.classList.remove('selected'));
    item.classList.add('selected');
    state.selectedQuality = item.dataset.quality;
  });
});

// ── Setup banner ─────────────────────────────────────────
function showSetupBanner() {
  document.getElementById('setupBanner').classList.remove('hidden');
}

const HELPER_DOWNLOAD_URL =
  'https://clip.usesimplytools.com/downloads/SimplyClip_Helper.exe';

document.getElementById('setupBtn').addEventListener('click', () => {
  chrome.downloads.download({
    url: HELPER_DOWNLOAD_URL,
    filename: 'SimplyClip_Helper.exe',
    saveAs: false
  });
});

function checkHelperWithRetry(retriesLeft, onSuccess, onFail) {
  chrome.runtime.sendMessage({ action: 'CHECK_HELPER' }, response => {
    if (response && response.ok) {
      onSuccess();
    } else if (retriesLeft > 0) {
      setTimeout(() => {
        checkHelperWithRetry(retriesLeft - 1, onSuccess, onFail);
      }, 2000);
    } else {
      onFail();
    }
  });
}

// ── Download ─────────────────────────────────────────────
downloadBtn.addEventListener('click', async () => {
  if (!state.videoId) return;

  downloadBtn.disabled = true;
  progressWrap.classList.remove('hidden');
  progressFill.style.width = '5%';
  progressLabel.textContent = 'Connecting to helper...';
  checkHelperWithRetry(3, startClipJob, () => {
    showError('Helper not running. Please run SimplyClip_Helper.exe');
    showSetupBanner();
  });
});

function startClipJob() {
  progressFill.style.width = '8%';
  progressLabel.textContent = 'Starting download...';

  const payload = {
    videoId: state.videoId,
    startSec: state.fullVideo ? 0 : state.startSec,
    endSec: state.fullVideo ? state.videoDuration : state.endSec,
    quality: state.selectedQuality || '1080',
    outputDir: null,
  };
  console.log('[SimplyClip] Starting clip job:', payload);

  chrome.runtime.sendMessage({
    action: 'START_CLIP',
    payload,
  }, response => {
    if (!response || response.status === 'error') {
      showError(response?.message || 'Download failed.');
      return;
    }
    pollProgress();
  });
}

function pollProgress() {
  const interval = setInterval(() => {
    chrome.runtime.sendMessage({ action: 'GET_PROGRESS' }, response => {
      if (!response) {
        clearInterval(interval);
        showError('Lost connection to helper.');
        return;
      }

      if (response.status === 'error') {
        clearInterval(interval);
        showError(response.message || 'Download failed.');
        return;
      }

      if (response.status === 'done') {
        clearInterval(interval);
        progressFill.style.width = '100%';
        progressLabel.textContent = '✓ Saved to Downloads folder';
        setTimeout(resetDownloadUI, 3000);
        return;
      }

      const pct = response.percent || 0;
      progressFill.style.width = pct + '%';
      progressLabel.textContent = response.message || 'Processing...';
    });
  }, 1000);
}

function showError(msg) {
  downloadBtn.disabled = false;
  progressLabel.textContent = `✗ ${msg}`;
  progressFill.style.background = '#e53e3e';
  setTimeout(resetDownloadUI, 3000);
}

function resetDownloadUI() {
  downloadBtn.disabled = false;
  progressWrap.classList.add('hidden');
  progressFill.style.width = '0%';
  progressFill.style.background = '';
}

// ── Init: get video info from active tab ──────────────────
function init() {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const tab = tabs[0];
    if (!tab || !tab.url || !tab.url.includes('youtube.com/watch')) {
      notYouTube.classList.remove('hidden');
      mainContent.classList.add('hidden');
      return;
    }

    notYouTube.classList.add('hidden');
    mainContent.classList.remove('hidden');

    try {
      const url = new URL(tab.url);
      state.videoId = url.searchParams.get('v');
    } catch (e) {}

    if (state.videoId) {
      videoThumb.src = `https://img.youtube.com/vi/${state.videoId}/mqdefault.jpg`;
    }

    chrome.runtime.sendMessage({ action: 'GET_VIDEO_INFO' }, response => {
      if (chrome.runtime.lastError || !response || response.error) {
        videoTitle.textContent = tab.title.replace(' - YouTube', '') || 'Unknown video';
        state.videoTitle = videoTitle.textContent;
        state.videoDuration = Math.round(600);
        state.startSec = 0;
        state.endSec = Math.round(state.videoDuration);
        videoDuration.textContent = '10:00:00';
        chrome.storage.local.get(['bracketStart', 'bracketEnd'], (data) => {
          if (data.bracketStart !== undefined) {
            state.startSec = Math.round(data.bracketStart);
          }
          if (data.bracketEnd !== undefined) {
            state.endSec = Math.round(data.bracketEnd);
          } else {
            state.endSec = state.videoDuration;
          }
          syncInputsFromState();
          updateTimeline();
        });
        buildTicks();
        return;
      }

      state.videoDuration = Math.round(response.duration || 600);
      state.startSec = 0;
      state.endSec = Math.round(state.videoDuration);
      state.videoTitle    = response.title || tab.title.replace(' - YouTube', '');

      videoTitle.textContent    = state.videoTitle;
      videoDuration.textContent = formatHMS(state.videoDuration);

      chrome.storage.local.get(['bracketStart', 'bracketEnd'], (data) => {
        if (data.bracketStart !== undefined) {
          state.startSec = Math.round(data.bracketStart);
        }
        if (data.bracketEnd !== undefined) {
          state.endSec = Math.round(data.bracketEnd);
        } else {
          state.endSec = state.videoDuration;
        }
        syncInputsFromState();
        updateTimeline();
      });
      buildTicks();
    });
  });
}

window.addEventListener('message', (e) => {
  if (e.data.type === 'YTC_BRACKET_UPDATE') {
    if (e.data.bracketStart !== undefined) {
      state.startSec = Math.round(e.data.bracketStart);
    }
    if (e.data.bracketEnd !== undefined) {
      state.endSec = Math.round(e.data.bracketEnd);
    }
    syncInputsFromState();
    updateTimeline();
  }
});

init();
